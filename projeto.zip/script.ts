document.addEventListener('DOMContentLoaded', () => {
    const fetchDataButton = document.getElementById('fetchData');
    const apiDataDiv = document.getElementById('apiData');

    // Mensagens de depuração
    console.log('fetchDataButton:', fetchDataButton);
    console.log('apiDataDiv:', apiDataDiv);

    if (fetchDataButton && apiDataDiv) {
        fetchDataButton.addEventListener('click', () => {
            const lyrics = `
                Yeah, you've been alone<br>
                I've been gone for far too long<br>
                But with all that we've been through<br>
                After all this time I'm coming home to you<br>
                Never let it show<br>
                The pain I've grown to know<br>
                'Cause with all these things we do<br>
                It don't matter when I'm coming home to you<br>
                I reach towards the sky I've said my goodbyes<br>
                My heart's always with you now<br>
                I won't question why so many have died<br>
                My prayers have made it through yeah<br>
                'Cause with all these things we do<br>
                It don't matter when I'm coming home to you<br>
                Letters keep me warm<br>
                Helped me through the storm<br>
                But with all that we've been through<br>
                After all this time I'm coming home to you<br>
                I reach towards the sky I've said my goodbyes<br>
                My heart's always with you now<br>
                I won't question why so many have died<br>
                My prayers have made it through yeah<br>
                'Cause with all these things we do<br>
                It don't matter when I'm coming home to you<br>
                I've always been true<br>
                I've waited so long just to come hold you<br>
                I'm making it through<br>
                It's been far too long, we've proven our<br>
                love over time's so strong, in all that we do<br>
                The stars in the night, they lend me their light<br>
                to bring me closer to heaven with you<br>
                But with all that we've been through<br>
                After all this time I'm coming home to you<br>
                I reach towards the sky I've said my goodbyes<br>
                My heart's always with you now<br>
                I won't question why so many have died<br>
                My prayers have made it through yeah<br>
                'Cause with all these things we do<br>
                It don't matter when I'm coming home to you<br>
                And with all that we've been through<br>
                After all this time I'm coming home to you
            `;

            apiDataDiv.innerHTML = lyrics;
        });
    } else {
        console.error('Elementos não encontrados.');
    }
});
